package com.example.branch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.WX.login;
import com.example.WX.R;
//设置界面
public class Mine_set extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mine_set);
        TextView change=(TextView)findViewById(R.id.mine_set_change);
        TextView back=(TextView)findViewById(R.id.mine_set_goback);
        TextView safety=(TextView)findViewById(R.id.safety);
        TextView adolescent=(TextView)findViewById(R.id.adolescent);
        TextView remind=(TextView)findViewById(R.id.remind);
        TextView notdisturb=(TextView)findViewById(R.id.notdisturb);
        TextView talk=(TextView)findViewById(R.id.talk);
        TextView privacy=(TextView)findViewById(R.id.privacy);
        TextView general=(TextView)findViewById(R.id.general);
        TextView about=(TextView)findViewById(R.id.about);
        TextView help=(TextView)findViewById(R.id.help);
//        账号与安全的点击事件
        safety.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine_set.this,"点击查看账号与安全",Toast.LENGTH_SHORT).show();
            }
        });
//        青少年模式的点击事件
        adolescent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine_set.this,"点击查看青少年模式",Toast.LENGTH_SHORT).show();
            }
        });
//        消息提醒的点击事件
        remind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine_set.this,"点击查看消息提醒",Toast.LENGTH_SHORT).show();
            }
        });
//        勿扰模式的点击事件
        notdisturb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine_set.this,"点击查看勿扰模式",Toast.LENGTH_SHORT).show();
            }
        });
//        聊天的点击事件
        talk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine_set.this,"点击查看聊天",Toast.LENGTH_SHORT).show();
            }
        });
//        隐私的点击事件
        privacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine_set.this,"点击查看隐私",Toast.LENGTH_SHORT).show();
            }
        });
//       通用的点击事件
        general.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine_set.this,"点击查看通用",Toast.LENGTH_SHORT).show();
            }
        });
//       关于的点击事件
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine_set.this,"点击查看关于",Toast.LENGTH_SHORT).show();
            }
        });
//       帮助与反馈的点击事件
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine_set.this,"点击查看帮助与反馈",Toast.LENGTH_SHORT).show();
            }
        });
//        切换账号
        change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Mine_set.this, login.class);
                startActivity(intent);
            }
        });
//        退出
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Mine_set.this, login.class);
                startActivity(intent);
            }
        });
    }
}