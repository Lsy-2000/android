package com.example.pyq;

import android.graphics.Bitmap;

public class fabu_list {
    private String pyqTw,pyqNa;
    private int imgHeadId;
    private Bitmap imgMainId1,imgMainId2,imgMainId3,imgMainId4,imgMainId5,imgMainId6;
    int imgMainId,imgMainIdb;
    public  fabu_list(String pyqTw, int imgHeadId, String pyqNa,Bitmap imgMainId1,Bitmap imgMainId2,Bitmap imgMainId3,Bitmap imgMainId4,Bitmap imgMainId5,Bitmap imgMainId6){
        this.imgHeadId=imgHeadId;
        this.pyqTw=pyqTw;
        this.imgMainId1=imgMainId1;
        this.imgMainId2=imgMainId2;
        this.imgMainId3=imgMainId3;
        this.imgMainId4=imgMainId4;
        this.imgMainId5=imgMainId5;
        this.imgMainId6=imgMainId6;

        this.pyqNa=pyqNa;
    }
    public  fabu_list(String pyqTw, int imgHeadId, String pyqNa,int imgMainId,int imgMainidb){
        this.imgHeadId=imgHeadId;
        this.pyqTw=pyqTw;
        this.imgMainId=imgMainId;
        this.imgMainIdb=imgMainidb;
        this.pyqNa=pyqNa;
    }



    public String getPyqNa() {
        return pyqNa;
    }

    public String getPyqTw() {
        return pyqTw;
    }

    public int getImgHeadId() {
        return imgHeadId;
    }

    public Bitmap getImgMainId1() {
        return imgMainId1;
    }

    public Bitmap getImgMainId3() {
        return imgMainId3;
    }

    public Bitmap getImgMainId4() {
        return imgMainId4;
    }

    public Bitmap getImgMainId5() {
        return imgMainId5;
    }

    public Bitmap getImgMainId6() {
        return imgMainId6;
    }

    public Bitmap getImgMainId2() {
        return imgMainId2;
    }

    public int getImgMainId() {
        return imgMainId;
    }

    public int getImgMainIdb() {
        return imgMainIdb;
    }
}
