package com.example.WX;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.homepage.MainActivity;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

//登陆页面
public class login extends AppCompatActivity {
//    存放用户名称，密码以及电话号码的数据库
    private UserDatabaseHelper udbhelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Button login=(Button) findViewById(R.id.login_login);
        final EditText userpassword=(EditText)findViewById(R.id.loginpassword);
        final EditText userphonenumber=(EditText)findViewById(R.id.loginphonenumber);
        TextView register=(TextView)findViewById(R.id.login_register);
        udbhelper=new UserDatabaseHelper(this,"RegisterStore.db",null,1);
//       跳转注册页面
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(login.this,register.class);
                startActivity(intent);
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                获取页面输入的密码以及电话号
                String phonenumber=userphonenumber.getText().toString();
                String password=userpassword.getText().toString();
//                获取数据库内数据
                SQLiteDatabase db=udbhelper.getWritableDatabase();
                Cursor cursor=db.query("register",null,null,null,null,null,null);
                cursor.moveToFirst();
//                判断密码和电话号是否输入正确
                do{
                    String getphonenumber=cursor.getString(cursor.getColumnIndex("phonenumber"));
                    String getpassword=cursor.getString(cursor.getColumnIndex("password"));
                    String getname=cursor.getString(cursor.getColumnIndex("name"));
//                    测试是否读取到数据库内数据
//                    Log.d("密码",getpassword);
//                    Log.d("电话号码",getphonenumber);
                    if(getphonenumber.equals(phonenumber)&&getpassword.equals(password))
                    {
                        Toast.makeText(login.this,"登录成功！",Toast.LENGTH_SHORT).show();
                        save(getname,getphonenumber);
                        Intent intent1=new Intent(login.this, MainActivity.class);
                        startActivity(intent1);
                    }
                    else if(getphonenumber.equals(phonenumber)&&!getpassword.equals(password)){
                        Toast.makeText(login.this,"密码错误，登录失败！",Toast.LENGTH_SHORT).show();
                    }
                    else if(!getphonenumber.equals(phonenumber)&&getpassword.equals(password)){
                        Toast.makeText(login.this,"电话号错误，登录失败！",Toast.LENGTH_SHORT).show();
                    }
                }while (cursor.moveToNext());
            }
        });
    }
//    将登录用户的姓名和电话号码存在文件中
    public void save(String username,String userphonenumber){
        FileOutputStream out=null;
        BufferedWriter writer=null;
        try{
            out=openFileOutput("userdata", Context.MODE_PRIVATE);
            writer=new BufferedWriter(new OutputStreamWriter(out));
            writer.write(username);
            writer.write(" ");
            writer.write(userphonenumber);
        }catch (IOException e){
            e.printStackTrace();
        }finally {
            try{
                if(writer!=null){
                    writer.close();
                }
            }catch (IOException e){
                e.printStackTrace();
            }
        }
    }
}