package com.example.pyq;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.example.homepage.discover;
import com.example.WX.R;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class pyqMainActivity extends AppCompatActivity {
    private List<fabu_list> fabu_lists=new ArrayList<>();
    private ImageView pyq_back,head,backMain;
    private TextView name;
    GridView gridView;
    private Bitmap bitmap1,bitmap2,bitmap3,bitmap4,bitmap5,bitmap6;
    private String user;
    private ViewGroup.LayoutParams pare;
    int icons[]=new int[]{R.drawable.a1,R.drawable.a2,R.drawable.a3};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pyq_main);
        pyq_back=findViewById(R.id.pyq_backImg);
        name=findViewById(R.id.pyq_name);
        backMain=findViewById(R.id.backmain);
//        从文件存储中取出用户信息（用于在此页显示）
        String[] userxinxi=load().split("\\s");
        user=userxinxi[0];
//        Log.d("name",user);
        name.setText(user);
        faBu();
        setPyq_back();
        setHead();
        useAdapter();
        getBackMain();
    }

    //    返回按钮返回
    public void getBackMain() {

        backMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(pyqMainActivity.this, discover.class);
                startActivity(intent);
            }
        });
    }

//    listView适配器

    public void useAdapter(){
        initFaBu();
        fuBuAdapter adapter=new fuBuAdapter(pyqMainActivity.this,R.layout.show,fabu_lists);
        ListView listView=findViewById(R.id.pyq_list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                fabu_list fabu_list=fabu_lists.get(position);
            }
        });
    }

    //点击发布按钮
    public void faBu(){
        Button faBu=findViewById(R.id.pyq_faBu);
        faBu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(pyqMainActivity.this,fubuactivity.class);
                startActivityForResult(intent,0);
            }
        });
    }

    //    发布朋友圈返回的数据
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        String data1=data.getStringExtra("data");
        bitmap1=  data.getParcelableExtra("bitmap1");
        bitmap2=  data.getParcelableExtra("bitmap2");
        bitmap3=  data.getParcelableExtra("bitmap3");
        bitmap4=  data.getParcelableExtra("bitmap4");
        bitmap5=  data.getParcelableExtra("bitmap5");
        bitmap6=  data.getParcelableExtra("bitmap6");
        fabu_list fabu=new fabu_list(data1,R.drawable.head,user,bitmap1,bitmap2,bitmap3,bitmap4,bitmap5,bitmap6);
        fabu_lists.add(0,fabu);


    }

    //    设置背景图片
    public void setPyq_back(){
        pyq_back.setImageResource(R.drawable.backgrund3);
        pyq_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
    //    设置头像
    public void setHead(){
        head=findViewById(R.id.pyq_head);
        head.setImageResource(R.drawable.head);
        //可将头像来源换成用户的
    }



    //    补充额外的朋友圈内容
    public void initFaBu(){
        fabu_list fabu1=new fabu_list("景色真美",R.drawable.a1,"张三",R.drawable.background2,R.drawable.backgrund3);
        fabu_lists.add(fabu1);
        fabu_list fabu2=new fabu_list("不知道说啥",R.drawable.a2,"李四",R.drawable.backgrund2,R.drawable.backgrund2);
        fabu_lists.add(fabu2);

    }

    //        从文件中读取用户数据
    public String load() {
        FileInputStream in = null;
        BufferedReader reader = null;
        StringBuilder content = new StringBuilder();
        try {
            in = openFileInput("userdata");
            reader = new BufferedReader(new InputStreamReader(in));
            String line = "";
            while ((line = reader.readLine()) != null) {
                content.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return content.toString();
    }
}
