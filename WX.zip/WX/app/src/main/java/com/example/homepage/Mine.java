package com.example.homepage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.branch.Mine_set;
import com.example.WX.R;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

//我的界面
public class Mine extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mine);
        ImageButton main = (ImageButton) findViewById(R.id.mine_m_weixin);
        ImageButton discover = (ImageButton) findViewById(R.id.mine_m_discover);
        ImageButton addressbook = (ImageButton) findViewById(R.id.mine_m_addressbook);
        TextView setting = (TextView) findViewById(R.id.mine_setting);
        TextView name=(TextView) findViewById(R.id.mine_text_nickname);
        TextView phonenumber=(TextView) findViewById(R.id.mine_text_number);
        LinearLayout pay=(LinearLayout)findViewById(R.id.pay);
        LinearLayout ollect=(LinearLayout)findViewById(R.id.ollect);
        LinearLayout album=(LinearLayout)findViewById(R.id.album);
        LinearLayout card=(LinearLayout)findViewById(R.id.card);
        LinearLayout emjio=(LinearLayout)findViewById(R.id.emjio);
//        支付一栏点击事件
        pay.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine.this,"点击查看支付",Toast.LENGTH_SHORT).show();;
            }
        });
//        收藏一栏点击事件
        ollect.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine.this,"点击查看收藏",Toast.LENGTH_SHORT).show();;
            }
        });
//        相册一栏点击事件
        album.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine.this,"点击查看相册",Toast.LENGTH_SHORT).show();;
            }
        });
//        卡包一栏点击事件
        card.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine.this,"点击查看卡包",Toast.LENGTH_SHORT).show();;
            }
        });
//        表情一栏点击事件
         emjio.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(Mine.this,"点击查看表情",Toast.LENGTH_SHORT).show();;
            }
        });
//        从文件存储中取出用户信息（用于在此页显示）
        String[] user=load().split("\\s");
        String username=user[0];
        String userphonenumber=user[1];
//        Log.d("123",username);
//        Log.d("223",userpassword);
//        显示用户昵称以及微信号
        name.setText("昵称："+username);
        phonenumber.setText("微信号："+userphonenumber);
//        进入设置页面
        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Mine.this, Mine_set.class);
                startActivity(intent);
            }
        });
//        跳转至主界面
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Mine.this, MainActivity.class);
                startActivity(intent);
            }
        });
//        跳转至发现界面
        discover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Mine.this, discover.class);
                startActivity(intent);
            }
        });
//        跳转至通信录
        addressbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Mine.this, addressbook.class);
                startActivity(intent);
            }
        });
    }
//        从文件中读取用户数据
    public String load() {
        FileInputStream in = null;
        BufferedReader reader = null;
        StringBuilder content = new StringBuilder();
        try {
            in = openFileInput("userdata");
            reader = new BufferedReader(new InputStreamReader(in));
            String line = "";
            while ((line = reader.readLine()) != null) {
                content.append(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return content.toString();
    }
}