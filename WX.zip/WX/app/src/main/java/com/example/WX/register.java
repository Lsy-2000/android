package com.example.WX;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

//注册界面
public class register extends AppCompatActivity {
    private UserDatabaseHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
//      存放用户数据的数据库
        dbHelper=new UserDatabaseHelper(this,"RegisterStore.db",null,1);
//        获取用户数据
        EditText username=(EditText)findViewById(R.id.registername);
        EditText userphonenumber=(EditText)findViewById(R.id.registerphonenumber);
        EditText userpassword=(EditText)findViewById(R.id.registerpassword);
        Button register=(Button)findViewById(R.id.registerregister);
//        checkbox为底部复选框，只有当勾选了复选框同意协议后才可进行注册，否则无法点击注册按钮
        CheckBox checkBox=(CheckBox)findViewById(R.id.checkBox);
        if(checkBox.isChecked()==false){
            register.setEnabled(false);
        }
        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    register.setEnabled(true);
                }else {
                    register.setEnabled(false);
                }
            }
        });
//        点击注册按钮将数据存入数据库内
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db=dbHelper.getWritableDatabase();
                ContentValues values=new ContentValues();
                String name=username.getText().toString();
                String phonenumber=userphonenumber.getText().toString();
                String password=userpassword.getText().toString();
                values.put("name",name);
                values.put("phonenumber",phonenumber);
                values.put("password",password);
                db.insert("register",null,values);
                Toast.makeText(register.this,"注册成功",Toast.LENGTH_SHORT).show();
                Intent intent=new Intent(register.this,login.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
