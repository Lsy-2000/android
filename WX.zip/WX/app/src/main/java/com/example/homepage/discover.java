package com.example.homepage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pyq.pyqMainActivity;
import com.example.WX.R;
//发现界面
public class discover extends AppCompatActivity {
    //右上角使用到的菜单
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainmenu,menu);
        return true;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discover);
        ImageButton main=(ImageButton)findViewById(R.id.discover_d_weixin);
        ImageButton addressbook=(ImageButton)findViewById(R.id.discover_d_addressbook);
        ImageButton mine=(ImageButton)findViewById(R.id.discover_d_mine);
        ImageButton add=(ImageButton)findViewById(R.id.discover_top_add);
        TextView friendcircle=(TextView)findViewById(R.id.discover_friendcircle);
        LinearLayout scan=(LinearLayout)findViewById(R.id.scan);
        LinearLayout shake=(LinearLayout)findViewById(R.id.shake);
        LinearLayout look=(LinearLayout)findViewById(R.id.look);
        LinearLayout search=(LinearLayout)findViewById(R.id.search);
        LinearLayout nearby=(LinearLayout)findViewById(R.id.nearby);
        LinearLayout shop=(LinearLayout)findViewById(R.id.shop);
        LinearLayout game=(LinearLayout)findViewById(R.id.game);
        LinearLayout app=(LinearLayout)findViewById(R.id.app);
//        扫一扫一栏点击事件
        scan.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(discover.this,"点击查看扫一扫",Toast.LENGTH_SHORT).show();;
            }
        });
//        摇一摇一栏点击事件
        shake.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(discover.this,"点击查看摇一摇",Toast.LENGTH_SHORT).show();;
            }
        });
//        看一看一栏点击事件
        look.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(discover.this,"点击查看看一看",Toast.LENGTH_SHORT).show();;
            }
        });
//        搜一搜一栏点击事件
        search.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(discover.this,"点击查看搜一搜",Toast.LENGTH_SHORT).show();;
            }
        });
//        附近的人一栏点击事件
        nearby.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(discover.this,"点击查看附近的人",Toast.LENGTH_SHORT).show();;
            }
        });
//        购物一栏点击事件
        shop.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(discover.this,"点击查看购物",Toast.LENGTH_SHORT).show();;
            }
        });
//        游戏一栏点击事件
        game.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(discover.this,"点击查看游戏",Toast.LENGTH_SHORT).show();;
            }
        });
//        小程序一栏点击事件
        app.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(discover.this,"点击查看附近的人",Toast.LENGTH_SHORT).show();;
            }
        });
//        点击添加按钮弹出菜单
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showmenu show=new showmenu();
                show.show(getApplicationContext(),add);
            }
        });
//        点击文字朋友圈进如朋友圈展示
        friendcircle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(discover.this, pyqMainActivity.class);
                startActivity(intent);
            }
        });
//        跳转至主界面
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(discover.this, MainActivity.class);
                startActivity(intent);
            }
        });
//        跳转至通信录
        addressbook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(discover.this,addressbook.class);
                startActivity(intent);
            }
        });
//        跳转至我的界面
        mine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(discover.this,Mine.class);
                startActivity(intent);
            }
        });
    }
}