package com.example.branch;
//消息的实体类
public class Talk_msg {
    public static final int TYPE_RECEIVED = 0;//表示收到好友的消息
    public static final int TYPE_SENT = 1;//表示用户发送的消息
    private String content;//消息内容
    private int type;//消息类型
    public Talk_msg(String c,int t){
        this.content=c;
        this.type=t;
    }
    public String getContent(){
        return content;
    }
    public int getType(){
        return type;
    }
}
