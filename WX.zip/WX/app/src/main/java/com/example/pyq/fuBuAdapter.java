package com.example.pyq;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;
import com.example.WX.R;
public class fuBuAdapter extends ArrayAdapter<fabu_list> {
    private int resourceID;
    private RelativeLayout.LayoutParams params;
    int icons[]=new int[]{R.drawable.backgrund,R.drawable.backgrund2,R.drawable.backgrund3,R.drawable.backgrund3};


    public fuBuAdapter(@NonNull Context context, int resource, @NonNull List<fabu_list> objects) {
        super(context, resource, objects);
        resourceID=resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        fabu_list fabu=getItem(position);
        View view= LayoutInflater.from(getContext()).inflate(resourceID,parent,false);

//        设置头像
        ImageView headImg=view.findViewById(R.id.pyq_head_img);
        headImg.setImageResource(fabu.getImgHeadId());

//        设置用户名
        TextView textName=view.findViewById(R.id.pyq_title_word);
        textName.setText(fabu.getPyqNa());


//        设置发布内容
        TextView textWord=view.findViewById(R.id.pyq_word);
        textWord.setText(fabu.getPyqTw());


        RelativeLayout relativeLayout=view.findViewById(R.id.photo_hose);


//        设置图片
        ImageView mainImg1=view.findViewById(R.id.pyq_img);
        ImageView mainImg2=view.findViewById(R.id.pyq_img2);
        ImageView mainImg3=view.findViewById(R.id.pyq_img3);
        ImageView mainImg4=view.findViewById(R.id.pyq_img4);
        ImageView mainImg5=view.findViewById(R.id.pyq_img5);
        ImageView mainImg6=view.findViewById(R.id.pyq_img6);
        if (fabu.getImgMainId1()!=null){
//            相机发回的图片
            if(fabu.getImgMainId4()==null){
                params= (RelativeLayout.LayoutParams) relativeLayout.getLayoutParams();
                params.height=350;
            }
            mainImg1.setImageBitmap(fabu.getImgMainId1());
            mainImg2.setImageBitmap(fabu.getImgMainId2());
            mainImg3.setImageBitmap(fabu.getImgMainId3());
            mainImg4.setImageBitmap(fabu.getImgMainId4());
            mainImg5.setImageBitmap(fabu.getImgMainId5());
            mainImg6.setImageBitmap(fabu.getImgMainId6());
        }
        else {
            params= (RelativeLayout.LayoutParams) relativeLayout.getLayoutParams();
            params.height=350;
//            自定义添加的图片
            mainImg1.setImageResource(fabu.getImgMainId());
            mainImg2.setImageResource(fabu.getImgMainIdb());
        }
        return view;
    }
}
