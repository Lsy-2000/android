package com.example.addfriend;
public class Friend {
    private String remark_name;
    public Friend(String name){
        this.remark_name = name;
    }
    public String getName(){
        return remark_name;
    }

}

