package com.example.WX;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;
//存放用户信息的数据库
public class UserDatabaseHelper extends SQLiteOpenHelper {
    public static final String CREATE_REGISTER="create table register ("
            + "name text, "
            + "phonenumber text,"
            + "password text)";
    private Context mContext;
    public UserDatabaseHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version){
        super(context,name,factory,version);
        mContext=context;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_REGISTER);
        Toast.makeText(mContext,"Create succeeded",Toast.LENGTH_SHORT).show();
    }
    public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){

    }
}