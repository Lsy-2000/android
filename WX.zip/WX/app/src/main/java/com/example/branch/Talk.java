package com.example.branch;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.WX.R;
import java.util.ArrayList;
import java.util.List;
//好友聊天主界面
public class Talk extends AppCompatActivity {
    private MessageDatabaseHelper mdbhelper;//存放信息的数据库
    private List<Talk_msg> list=new ArrayList<>();//动态存放信息
    private RecyclerView talkshow;
    private Talk_msgAdapter talkmsg;//recyclerview的适配器
    private Button send;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_talk);
//        存放聊天记录的数据库
        mdbhelper= new MessageDatabaseHelper(this,"MessageStore.db",null,1);
        mdbhelper.getWritableDatabase();
        SQLiteDatabase mdb=mdbhelper.getWritableDatabase();
//        获取数据库中的信息
        Cursor cursor=mdb.query("message",null,null,null,null,null,null);
//        页面中各部件
        EditText input=(EditText)findViewById(R.id.Talk_input);//用户输入消息的发送框
        send=(Button)findViewById(R.id.Talk_send);//发送按钮
        talkshow=(RecyclerView)findViewById(R.id.Talk_showmessage);
        LinearLayoutManager layoutManager = new LinearLayoutManager ( this);
        talkshow.setLayoutManager(layoutManager);
        talkmsg=new Talk_msgAdapter(list);
        talkshow.setAdapter(talkmsg);
//        添加好友后好友自动回复
        Talk_msg received=new Talk_msg("你好。",Talk_msg.TYPE_RECEIVED);
        list.add (received);
//        显示之前发送的消息
        cursor.moveToFirst();
        if(cursor.getCount()!=0)
        {
            do {
                String message = cursor.getString(cursor.getColumnIndex("message"));
                Talk_msg send = new Talk_msg(message, Talk_msg.TYPE_SENT);
                list.add(send);
            } while (cursor.moveToNext());
        }
//        点击发送按钮显示消息
        send.setOnClickListener ( new View.OnClickListener () {
            @Override
            public void onClick(View view) {
                String content = input.getText ().toString ();
                if(!"".equals ( content )){//如果输入框不为空，就执行以下内容
                    ContentValues values=new ContentValues();
                    values.put("message",content);
                    mdb.insert("message",null,values);
                    Talk_msg msg = new Talk_msg( content,Talk_msg.TYPE_SENT );
                    list.add ( msg );
                    talkmsg.notifyItemInserted (list.size ()-1);
                    talkshow.scrollToPosition ( list.size ()-1 );//将显示的数据定位到 最后一行
                    input.setText ( "" );//点击发送后清空输入框的内容
                }
            }
        } );

    }

}