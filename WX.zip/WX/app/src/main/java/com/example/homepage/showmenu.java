package com.example.homepage;

import android.content.Context;
import android.content.Intent;
import android.widget.ImageButton;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.addfriend.Addfriend;
import com.example.WX.R;

public class showmenu {
    void show(Context context,ImageButton top_add) {
        //menu添加到指定的Button
        PopupMenu popupMenu = new PopupMenu(context,top_add);
        popupMenu.getMenuInflater().inflate(R.menu.mainmenu,popupMenu.getMenu());
//       menu的点击事件
        popupMenu.setOnMenuItemClickListener((item-> {
            switch (item.getItemId()){
                case R.id.group_chat:
                    Toast.makeText(context, item.getTitle(), Toast.LENGTH_SHORT).show();
                    break;
                case R.id.add_friend:
                    Toast.makeText(context, item.getTitle(), Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(context, Addfriend.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                    break;
                case R.id.scan:
                    Toast.makeText(context, item.getTitle(), Toast.LENGTH_SHORT).show();
                    break;
                case R.id.pay:
                    Toast.makeText(context, item.getTitle(), Toast.LENGTH_SHORT).show();
                    break;
            case R.id.help:
                Toast.makeText(context, item.getTitle(), Toast.LENGTH_SHORT).show();
                break;
        }
        return false;
        }));
        popupMenu.show();
    }
}
