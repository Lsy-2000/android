package com.example.branch;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import com.example.WX.R;

//聊天界面里显示聊天信息的RecyclerView部件的适配器
public class Talk_msgAdapter extends RecyclerView.Adapter<Talk_msgAdapter.ViewHolder> {
    private List<Talk_msg> list;
    static class ViewHolder  extends  RecyclerView.ViewHolder{
        LinearLayout leftLayout;
        LinearLayout rightLayout;
        TextView  leftMsg;
        TextView rightMsg;
        ImageView leftimageview;
        ImageView rightimageview;

        public ViewHolder(View view){
            super(view);
            leftLayout = (LinearLayout) view.findViewById (R.id.layout_left);
            rightLayout = (LinearLayout) view.findViewById ( R.id.layout_right );
            leftMsg = (TextView) view.findViewById ( R.id.left_msg );
            rightMsg = (TextView) view.findViewById ( R.id.right_msg );
            leftimageview=(ImageView)view.findViewById(R.id.left_headsculpture);
            rightimageview=(ImageView)view.findViewById(R.id.right_headsculpture);
        }
    }

    public Talk_msgAdapter(List<Talk_msg> list) {
        this.list=list;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from ( parent.getContext ()).inflate(R.layout.activity_talk_showmessage_item,parent,false);
        return new ViewHolder ( view );
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
//        得到实例
          Talk_msg msg=list.get(position);
        if (msg.getType()==Talk_msg.TYPE_RECEIVED){//表示收到消息
            holder.leftLayout.setVisibility ( View.VISIBLE );//显示好友的消息布局
            holder.rightLayout.setVisibility ( View.GONE );//隐藏用户的消息布局
            holder.leftMsg.setText ( msg.getContent () );
        }else if (msg.getType()==Talk_msg.TYPE_SENT){//表示发送消息
            holder.rightLayout.setVisibility ( View.VISIBLE );
            holder.leftLayout.setVisibility ( View.GONE );
            holder.rightMsg.setText ( msg.getContent () );
        }

    }
    @Override
    public int getItemCount() {
        return list.size();
    }


}
