package com.example.addfriend;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.WX.UserDatabaseHelper;
import com.example.homepage.MainActivity;
import com.example.WX.R;

public class Addfriend extends AppCompatActivity {
    private UserDatabaseHelper udbhelper;
    private FriendInfo friendInfo;
    private EditText editText;
    private TextView textView;
    private RelativeLayout relative;
    private TextView showView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addfriend);
        udbhelper=new UserDatabaseHelper(this,"RegisterStore.db",null,1);//存放用户信息的数据库
        friendInfo=new FriendInfo(this,"FriendStore.db",null,1);//存放好友列表的数据库
        editText = (EditText)findViewById(R.id.et_search);
        textView = (TextView)findViewById(R.id.tv_search);
        relative = (RelativeLayout)findViewById(R.id.re_search);
        showView = (TextView)findViewById(R.id.show_search);

        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length()>0){
                    relative.setVisibility(View.VISIBLE);
                    textView.setText(editText.getText().toString().trim());
                }
                else {
                    relative.setVisibility(View.GONE);
                    textView.setText("");
                }
            }
            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        relative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uid = editText.getText().toString().trim();
                if (uid == null || uid.equals("")){
                    return;
                }
                else{
                    searchUers(uid);
                }
            }
        });
    }
    private void searchUers(String uid){
        int flag=0;
        ProgressDialog dialog = new ProgressDialog(Addfriend.this);
        dialog.setMessage("正在查找联系人...");
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.show();
        SQLiteDatabase db=udbhelper.getWritableDatabase();
        SQLiteDatabase fi=friendInfo.getWritableDatabase();
        ContentValues values = new ContentValues();
        Cursor cursor=db.query("register",null,null,null,null,null,null);
        if(cursor.moveToFirst()) {
            do{
                String phonenumber=cursor.getString(cursor.getColumnIndex("phonenumber"));
                String name=cursor.getString(cursor.getColumnIndex("name"));
                if(phonenumber.equals(uid))
                {
                    flag=1;
                    dialog.dismiss();
                    showView.setVisibility(View.GONE);
                    values.put("friendname",name);
                    values.put("friendphone",phonenumber);
                    fi.insert("friend",null,values);
                    Toast.makeText(Addfriend.this,"用户存在,添加好友成功!",Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(Addfriend.this, MainActivity.class);
                    startActivity(intent);
                    break;
                }
            }while (cursor.moveToNext());
            if (flag==0){
                dialog.dismiss();
                showView.setVisibility(View.VISIBLE);
                showView.setText("此用户不存在");
            }
        }
    }
}
