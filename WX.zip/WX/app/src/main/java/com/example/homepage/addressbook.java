package com.example.homepage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.addfriend.Friend;
import com.example.addfriend.FriendAdapter;
import com.example.addfriend.FriendInfo;
import com.example.addfriend.OnItemClickListener;
import com.example.branch.Talk;
import com.example.WX.R;

import java.util.ArrayList;
import java.util.List;

//通信录界面
public class addressbook extends AppCompatActivity {
    private FriendInfo friendInfo;
    private List<Friend> list=new ArrayList<>();//动态存放好友信息
    private RecyclerView showfriend;
    private FriendAdapter friend;//recyclerview的适配器
    //右上角使用到的菜单
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainmenu,menu);
        return true;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addressbook);
        showfriend=(RecyclerView)findViewById(R.id.addressbook_showfriend);
        ImageButton main=(ImageButton)findViewById(R.id.addressbook_ab_weixin);
        ImageButton discover=(ImageButton)findViewById(R.id.addressbook_ab_discover);
        ImageButton mine=(ImageButton)findViewById(R.id.addressbook_ab_mine);
        ImageButton add=(ImageButton)findViewById(R.id.addressbook_top_add);
        LinearLayout newfriend=(LinearLayout)findViewById(R.id.new_friend);
        LinearLayout group=(LinearLayout)findViewById(R.id.group);
        LinearLayout label=(LinearLayout)findViewById(R.id.label);
        LinearLayout account=(LinearLayout)findViewById(R.id.account);
//        新的朋友一栏点击事件
        newfriend.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(addressbook.this,"点击查看新的朋友",Toast.LENGTH_SHORT).show();;
            }
        });
//        群聊一栏点击事件
        group.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(addressbook.this,"点击查看群聊",Toast.LENGTH_SHORT).show();;
            }
        });
//        标签一栏点击事件
        label.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(addressbook.this,"点击查看标签",Toast.LENGTH_SHORT).show();;
            }
        });
//        公众号一栏点击事件
        account.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Toast.makeText(addressbook.this,"点击查看公众号",Toast.LENGTH_SHORT).show();;
            }
        });
//      从存放好友信息的数据库中读取信息并显示在页面中
        friendInfo= new FriendInfo(this,"FriendStore.db",null,1);
        friendInfo.getWritableDatabase();
        SQLiteDatabase fdb=friendInfo.getWritableDatabase();
        Cursor cursor=fdb.query("friend",null,null,null,null,null,null);
        if(cursor.moveToNext()){
            do{
                Friend friend=new Friend(cursor.getString(cursor.getColumnIndex("friendname")));
                list.add(friend);
            }while (cursor.moveToNext());
        }
        LinearLayoutManager layoutManager = new LinearLayoutManager ( this);
        showfriend.setLayoutManager(layoutManager);
        friend=new FriendAdapter(list);
        showfriend.setAdapter(friend);
//      添加好友的点击事件,进行聊天操作
        showfriend.setAdapter(friend);
        friend.setItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClickListeren(View view) {
                Intent intent =new Intent(addressbook.this, Talk.class);
                startActivity(intent);
            }
        });

//        菜单点击事件
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showmenu show=new showmenu();
                show.show(getApplicationContext(),add);
            }
        });
//        跳转至主界面
        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(addressbook.this, MainActivity.class);
                startActivity(intent);
            }
        });
//        跳转至发现界面
        discover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(addressbook.this,discover.class);
                startActivity(intent);
            }
        });
//        跳转我的界面
        mine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(addressbook.this,Mine.class);
                startActivity(intent);
            }
        });
    }
}