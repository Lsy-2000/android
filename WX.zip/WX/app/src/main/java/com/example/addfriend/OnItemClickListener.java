package com.example.addfriend;

import android.view.View;

public interface OnItemClickListener {
    void onItemClickListeren(View view);
}
