package com.example.pyq;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.example.WX.R;

public class fubuactivity extends AppCompatActivity {
    private Button buttonCa, fuBuButton;
    private ImageView imageV, imageV2, imageV3, imageV4, imageView, imageV5, imageV6;
    private final int CAMERA_REQUEST = 10;
    private int num = 0;
    private Bitmap[] bitmap1;
    private EditText faWord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fubuactivity);
        imageV = findViewById(R.id.faBu_img);
        imageV2 = findViewById(R.id.faBu_img2);
        imageV3 = findViewById(R.id.faBu_img3);
        imageV4 = findViewById(R.id.faBu_img4);
        imageV5 = findViewById(R.id.faBu_img5);
        imageV6 = findViewById(R.id.faBu_img6);
        buttonCa = findViewById(R.id.faBu_add);
        initView();
        fuBuButton = findViewById(R.id.faBu_faB);
        faWord = findViewById(R.id.faBu_word);
        bitmap1 = new Bitmap[6];
        faBuButton();

    }

    //点击发布后传图片
    public void faBuButton() {
        fuBuButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String data = faWord.getText().toString();

                if (data.length() == 0) {
                    Toast.makeText(fubuactivity.this, "请输入文字", Toast.LENGTH_SHORT).show();
                } else {
                    Intent intent = getIntent();
                    intent.putExtra("bitmap1", bitmap1[0]);
                    intent.putExtra("bitmap2", bitmap1[1]);
                    intent.putExtra("bitmap3", bitmap1[2]);
                    intent.putExtra("bitmap4", bitmap1[3]);
                    intent.putExtra("bitmap5", bitmap1[4]);
                    intent.putExtra("bitmap6", bitmap1[5]);

                    intent.putExtra("data", data);
                    setResult(0, intent);
                    finish();
                }
            }
        });
    }

    //    调用相机
    public void initView() {

        buttonCa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA_REQUEST);
            }
        });

    }


    //    从相机返回并取得bitmap的数据
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {


        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case CAMERA_REQUEST:
                if (resultCode == RESULT_OK) {
                    Bitmap bitmap = (Bitmap) data.getExtras().get("data");

                    switch (num) {
                        case 0:
                            imageV.setImageBitmap(bitmap);
                            break;
                        case 1:
                            imageV2.setImageBitmap(bitmap);
                            break;
                        case 2:
                            imageV3.setImageBitmap(bitmap);
                            break;
                        case 3:
                            imageV4.setImageBitmap(bitmap);
                            break;
                        case 4:
                            imageV5.setImageBitmap(bitmap);
                            break;
                        case 5:
                            imageV6.setImageBitmap(bitmap);
                            break;
                        default:
                            break;
                    }
                    bitmap1[num] = bitmap;
                    num++;
                }
                break;
        }
    }
}