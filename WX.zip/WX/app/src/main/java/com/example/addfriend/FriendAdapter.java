package com.example.addfriend;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.example.WX.R;
import java.util.List;

public class FriendAdapter extends RecyclerView.Adapter<FriendAdapter.ViewHolder> {
    private List<Friend> mFriend;
    private OnItemClickListener mlistener;
    public void setItemClickListener(OnItemClickListener listener){
        mlistener = listener;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView friendImage;
        TextView friendName;
        View friendView;

        public ViewHolder(View view) {
            super(view);
            friendImage = (ImageView) view.findViewById(R.id.friend_image);
            friendName = (TextView) view.findViewById(R.id.friend_name);
            friendView = view;
        }
    }
    public FriendAdapter(List<Friend> friendList){
        mFriend = friendList;
    }

    @Override
    public FriendAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.friend_item,parent,false);
        final ViewHolder holder = new ViewHolder(view);
        //Recycle内Item的接口回调
        if (mlistener !=null){
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mlistener.onItemClickListeren(v);
                }
            });
        }
//设置头像
//        holder.friendImage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                int position = holder.getAdapterPosition();
//                Friend friend = mFriend.get(position);
//                Toast.makeText(v.getContext(),"你点击了好友"+friend.getName()+"的头像",Toast.LENGTH_SHORT).show();
//            }
//        });
        return holder;
    }
    @Override
    public void onBindViewHolder(FriendAdapter.ViewHolder holder, int position) {
        Friend friend = mFriend.get(position);
        holder.friendName.setText(friend.getName());
    }
    @Override
    public int getItemCount() {
        return mFriend.size();
    }
}
